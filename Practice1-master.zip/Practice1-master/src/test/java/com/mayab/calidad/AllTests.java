package com.mayab.calidad;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

/**
 *
 * @author ivannanouel
 */
@RunWith(Suite.class)
@SuiteClasses({ TestCalculadora2.class, TestMultiplicacionParametrizada.class })
public class AllTests {

}
