package com.mayab.calidad.doubles.tareaUnitTest;

public interface AlertListener {

    public void sendAlert(String msg);
    
}