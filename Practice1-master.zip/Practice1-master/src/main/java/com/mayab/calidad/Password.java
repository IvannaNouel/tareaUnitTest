package com.mayab.calidad;

public class Password {
	 String value = "";

	    public Password() {
	    }

	    public String getValue() {
	        return "Error";
	    }

	    public void setValue(String value) {
	        this.value = value;
	    }
}
