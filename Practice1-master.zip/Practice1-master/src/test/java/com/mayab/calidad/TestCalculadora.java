package com.mayab.calidad;

/**
 *
 * @author ivannanouel
 */
public class TestCalculadora {

}
