package com.mayab.calidad;

public class SubDependency {

	public String getClassName(){
		
		return this.getClassName();		
	}
}
