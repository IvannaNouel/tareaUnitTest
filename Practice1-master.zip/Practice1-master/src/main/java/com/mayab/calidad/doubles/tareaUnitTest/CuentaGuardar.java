package com.mayab.calidad.doubles.tareaUnitTest;

public interface CuentaGuardar {

	public transaction guardar(transaction t);
	
	
	
	
}
	
	

